# ReCeiVe

The LuaLaTex class ReCeiVe provides a wide variety of possible cv structures and allows the user to change many details easily. The class is written in such a manner that it should not be necessary to alternate it in any way in order to get the desired cv layout. More or less all macros and commands should be commented to provide the necessary transparency to facilitate the use of the class as much as possible.
